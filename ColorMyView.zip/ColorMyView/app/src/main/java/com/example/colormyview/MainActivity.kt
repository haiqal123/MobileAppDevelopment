package com.example.colormyview

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setListeners()
    }

    private fun makeColored(view: View){
        when (view.id){
            R.id.box_1_text -> view.setBackgroundColor(Color.DKGRAY)
            R.id.box_2_text -> view.setBackgroundColor(Color.GRAY)
            R.id.box_3_text -> view.setBackgroundColor(Color.BLUE)
            R.id.box_4_text -> view.setBackgroundColor(Color.MAGENTA)
            R.id.box_5_text -> view.setBackgroundColor(Color.GREEN)
            else -> view.setBackgroundColor(Color.LTGRAY)
        }
    }

    private fun setListeners(){
        val box_1_text = findViewById<TextView>(R.id.box_1_text)
        val box_2_text = findViewById<TextView>(R.id.box_2_text)
        val box_3_text = findViewById<TextView>(R.id.box_3_text)
        val box_4_text = findViewById<TextView>(R.id.box_4_text)
        val box_5_text = findViewById<TextView>(R.id.box_5_text)

        val rootConstraintLayout = findViewById<View>(R.id.constraint_layout)

        val clickableViews: List<View> =
            listOf(box_1_text, box_2_text, box_3_text, box_4_text, box_5_text, rootConstraintLayout)

        for (item :View in clickableViews) {
            item.setOnClickListener{makeColored(it)}
        }
    }

}